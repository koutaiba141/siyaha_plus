import 'dart:convert';
import 'package:http/http.dart' as http;
import 'company.dart';

class CompanyService {
  final String apiUrl = 'https://your-api-url.com/api/companies';

  Future<List<Company>> fetchCompanies() async {
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((companyJson) => Company.fromJson(companyJson)).toList();
    } else {
      throw Exception('Failed to load companies');
    }
  }

  Future<Company> fetchCompanyById(int id) async {
    final response = await http.get(Uri.parse('$apiUrl/$id'));

    if (response.statusCode == 200) {
      return Company.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load company');
    }
  }

  Future<void> addCompany(Company company) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(company.toJson()),
    );

    if (response.statusCode != 201) {
      throw Exception('Failed to add company');
    }
  }



  Future<void> deleteCompany(int id) async {
    final response = await http.delete(Uri.parse('$apiUrl/$id'));

    if (response.statusCode != 200) {
      throw Exception('Failed to delete company');
    }
  }
}
