import 'dart:convert';
import 'package:http/http.dart' as http;
import 'tourplan.dart';

class TourPlanService {
  final String apiUrl = 'https://your-api-url.com/api/tourplans';

  Future<List<TourPlan>> fetchTourPlans() async {
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((tourPlanJson) => TourPlan.fromJson(tourPlanJson)).toList();
    } else {
      throw Exception('Failed to load tour plans');
    }
  }

  Future<TourPlan> fetchTourPlanById(int id) async {
    final response = await http.get(Uri.parse('$apiUrl/$id'));

    if (response.statusCode == 200) {
      return TourPlan.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load tour plan');
    }
  }

  Future<void> addTourPlan(TourPlan tourPlan) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(tourPlan.toJson()),
    );

    if (response.statusCode != 201) {
      throw Exception('Failed to add tour plan');
    }
  }

  Future<void> updateTourPlan(TourPlan tourPlan) async {
    final response = await http.put(
      Uri.parse('$apiUrl/${tourPlan.id}'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(tourPlan.toJson()),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to update tour plan');
    }
  }

  Future<void> deleteTourPlan(int id) async {
    final response = await http.delete(Uri.parse('$apiUrl/$id'));

    if (response.statusCode != 200) {
      throw Exception('Failed to delete tour plan');
    }
  }
}
