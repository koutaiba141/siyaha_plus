import 'dart:convert';
import 'package:http/http.dart' as http;
import 'tour.dart';

class TourService {
  final String apiUrl = 'https://your-api-url.com/api/tours';

  Future<List<Tour>> fetchTours() async {
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((tourJson) => Tour.fromJson(tourJson)).toList();
    } else {
      throw Exception('Failed to load tours');
    }
  }

  Future<Tour> fetchTourById(int id) async {
    final response = await http.get(Uri.parse('$apiUrl/$id'));

    if (response.statusCode == 200) {
      return Tour.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load tour');
    }
  }

  Future<void> addTour(Tour tour) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(tour.toJson()),
    );

    if (response.statusCode != 201) {
      throw Exception('Failed to add tour');
    }
  }



  Future<void> deleteTour(int id) async {
    final response = await http.delete(Uri.parse('$apiUrl/$id'));

    if (response.statusCode != 200) {
      throw Exception('Failed to delete tour');
    }
  }
}
