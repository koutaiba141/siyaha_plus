class Company {
  final int id;
  final String companyName;
  final String companyEmail;
  final String companyAddress;
  final List<CompanyPhone> companyPhones;
  final List<CompanySocial> companySocials;
  final List<CompanyOwner> companyOwners;

  Company({
    required this.id,
    required this.companyName,
    required this.companyEmail,
    required this.companyAddress,
    required this.companyPhones,
    required this.companySocials,
    required this.companyOwners,
  });

  factory Company.fromJson(Map<String, dynamic> json) {
    var phoneList = json['phone_numbers'] as List;
    var socialList = json['social_media'] as List;
    var ownerList = json['owners'] as List;

    return Company(
      id: json['id'],
      companyName: json['company_name'],
      companyEmail: json['company_email'],
      companyAddress: json['company_address'],
      companyPhones: phoneList.map((i) => CompanyPhone.fromJson(i)).toList(),
      companySocials: socialList.map((i) => CompanySocial.fromJson(i)).toList(),
      companyOwners: ownerList.map((i) => CompanyOwner.fromJson(i)).toList(),
    );
  }
}

class CompanyPhone {
  final String phoneNumber;

  CompanyPhone({required this.phoneNumber});

  factory CompanyPhone.fromJson(Map<String, dynamic> json) {
    return CompanyPhone(phoneNumber: json['phone_number']);
  }
}

class CompanySocial {
  final String socialType;
  final String socialLink;

  CompanySocial({required this.socialType, required this.socialLink});

  factory CompanySocial.fromJson(Map<String, dynamic> json) {
    return CompanySocial(
      socialType: json['social_type'],
      socialLink: json['social_link'],
    );
  }
}

class CompanyOwner {
  final String ownerName;
  final String ownerEmail;
  final String ownerPhone;

  CompanyOwner({required this.ownerName, required this.ownerEmail, required this.ownerPhone});

  factory CompanyOwner.fromJson(Map<String, dynamic> json) {
    return CompanyOwner(
      ownerName: json['owner_name'],
      ownerEmail: json['owner_email'],
      ownerPhone: json['owner_phone'],
    );
  }
}
