class Tour {
  final int id;
  final String tourName;
  final String tourDescription;
  final int companyId;
  final List<TourImage> images;
  final List<TourPlan> tourPlans;
  final List<Category> categories;

  Tour({
    required this.id,
    required this.tourName,
    required this.tourDescription,
    required this.companyId,
    required this.images,
    required this.tourPlans,
    required this.categories,
  });

  factory Tour.fromJson(Map<String, dynamic> json) {
    var imageList = json['images'] as List;
    var planList = json['plans'] as List;
    var categoryList = json['categories'] as List;

    return Tour(
      id: json['id'],
      tourName: json['tour_name'],
      tourDescription: json['tour_description'],
      companyId: json['company_id'],
      images: imageList.map((i) => TourImage.fromJson(i)).toList(),
      tourPlans: planList.map((i) => TourPlan.fromJson(i)).toList(),
      categories: categoryList.map((i) => Category.fromJson(i)).toList(),
    );
  }
}

class TourImage {
  final String imagePath;

  TourImage({required this.imagePath});

  factory TourImage.fromJson(Map<String, dynamic> json) {
    return TourImage(imagePath: json['image_path']);
  }
}

class TourPlan {
  final String planName;
  final String planDescription;
  final String startDate;
  final String endDate;
  final double price;

  TourPlan({
    required this.planName,
    required this.planDescription,
    required this.startDate,
    required this.endDate,
    required this.price,
  });

  factory TourPlan.fromJson(Map<String, dynamic> json) {
    return TourPlan(
      planName: json['plan_name'],
      planDescription: json['plan_description'],
      startDate: json['start_date'],
      endDate: json['end_date'],
      price: json['price'],
    );
  }
}

class Category {
  final int id;
  final String name;

  Category({required this.id, required this.name});

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      id: json['id'],
      name: json['name'],
    );
  }
}
