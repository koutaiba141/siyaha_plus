class TourPlan {
  final int id;
  final String date;
  final String description;
  final int tourId;

  TourPlan({
    required this.id,
    required this.date,
    required this.description,
    required this.tourId,
  });

  factory TourPlan.fromJson(Map<String, dynamic> json) {
    return TourPlan(
      id: json['id'],
      date: json['date'],
      description: json['description'],
      tourId: json['tour_id'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date,
      'description': description,
      'tour_id': tourId,
    };
  }
}
